================================
Django admin material able V:0.1
================================

Django material admin is a Django admin based on material design.

This django app is tested on python 3.8 and django 3.0

Installation
------------

1. Add "material_admin" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        'material_admin',
        'django.contrib.admin',
        ...
    ]

2. Run ``python3 manage.py runserver`` to start server.

3. Visit http://127.0.0.1:8000/admin/
