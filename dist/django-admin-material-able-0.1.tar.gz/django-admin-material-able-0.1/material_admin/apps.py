from django.apps import AppConfig


class DjangomaterialableConfig(AppConfig):
    name = 'material_admin'
